<template>
	<div id="code">
        <x-header title="输入验证码支付" class="fixed-top" :left-options="{backText: ''}"></x-header>
		<div class="mui-content content fixed-content">
			<div class="code-tips">本次交易需要短信确认，验证码已发送至您的手机!<br />请输入6位数验证码。</div>
			<div class="mui-content fixed-content">
				<form id='regist-form' class="mui-input-group">
					<div class="mui-input-row">
						<input id='yzm' type="text" v-model="yzm" class="mui-input-clear mui-input password" maxlength="6" placeholder="请输入验证码">
					</div>
				</form>
				<div class="mui-content-padded">
					<button id='login' class="mui-btn mui-btn-block mui-button" @click="code_pay()">下一步</button>
					
				</div>
			</div>
		</div>
	</div>
</template>
<script>
import { XHeader } from 'vux';
	export default {
		name:"code",
		data(){
			return {
				money_order_no:this.$route.query.money_order_no,
			}
		},
		mounted(){
			console.log(money_order_no);
			
        },
        methods:{
			
		},
        components: {
            XHeader
        }
    }
</script>

<style scoped >

.code-tips{padding: 20px 30px; font-size: 14px; color: #999999; text-align: center;}
#code-form{height: 400px;}

</style>
